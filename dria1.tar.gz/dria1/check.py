# -*- coding: utf-8 -*-
import docker
import sys
import re
from prettytable import PrettyTable
from colorama import init, Fore, Style

# Инициализация colorama для корректной работы цветов в терминале
init(autoreset=True)

sys.stdout.reconfigure(encoding='utf-8')

def get_dria_containers(client):
    """Получить список всех контейнеров с именем, содержащим 'dria'"""
    containers = client.containers.list(all=True, filters={"name": "dria"})
    containers.sort(key=lambda x: int(re.search(r'\d+$', x.name).group()) if re.search(r'\d+$', x.name) else 0)
    return containers

def parse_steps_from_logs(logs):
    """Извлечь данные о шагах из логов"""
    pattern = r"Points: (\d+) total, (\d+) earned in this run,.*"
    total_steps = 0
    earned_steps = 0
    
    log_lines = logs.decode('utf-8').splitlines()
    
    for line in log_lines:
        match = re.search(pattern, line)
        if match:
            total_steps = int(match.group(1))
            earned_steps = int(match.group(2))
    
    return total_steps, earned_steps

def create_table_for_containers(containers):
    """Создать таблицу для списка контейнеров с фиксированной шириной столбцов"""
    table = PrettyTable()
    table.field_names = ["Контейнер", "Общее", "Заработано"]
    
    # Задаем фиксированную ширину столбцов
    table._min_width = {"Контейнер": 10, "Общее": 8, "Заработано": 10}
    table._max_width = {"Контейнер": 10, "Общее": 8, "Заработано": 10}
    
    for container in containers:
        try:
            logs = container.logs()
            total_steps, earned_steps = parse_steps_from_logs(logs)
            table.add_row([container.name, total_steps, earned_steps])
        except Exception as e:
            print(f"[ERROR] Не удалось обработать логи контейнера {container.name}: {e}")
            table.add_row([container.name, "Ошибка", "Ошибка"])
    return table

def colorize_row(row, is_header=False):
    """Раскрасить строку таблицы: границы белые, столбцы с разными цветами"""
    # Разделяем строку на части (столбцы) по символу "|"
    parts = row.split("|")
    
    # Цвета для каждого столбца
    colors = {
        "border": Fore.WHITE,              # Цвет границ таблицы (белый)
        "Контейнер": Fore.LIGHTCYAN_EX,    # Цвет столбца "Контейнер" (светло-голубой)
        "Общее": Fore.LIGHTYELLOW_EX,      # Цвет столбца "Общее" (светло-жёлтый)
        "Заработано": Fore.LIGHTGREEN_EX   # Цвет столбца "Заработано" (светло-зелёный)
    }
    
    # Собираем строку обратно с цветами
    colored_parts = []
    for i, part in enumerate(parts):
        if i == 0 or i == len(parts) - 1:
            # Первая и последняя часть — это границы, красим в белый
            colored_parts.append(colors["border"] + part + Style.RESET_ALL)
        elif i == 1:
            # Первый столбец (Контейнер)
            colored_parts.append(colors["Контейнер"] + part + Style.RESET_ALL)
        elif i == 2:
            # Второй столбец (Общее)
            colored_parts.append(colors["Общее"] + part + Style.RESET_ALL)
        elif i == 3:
            # Третий столбец (Заработано)
            colored_parts.append(colors["Заработано"] + part + Style.RESET_ALL)
        else:
            # Разделители между столбцами — белые
            colored_parts.append(colors["border"] + part + Style.RESET_ALL)
    
    # Собираем строку обратно
    return "|".join(colored_parts)

def monitor_dria_logs():
    """Отслеживать логи контейнеров dria и выводить три таблицы рядом с цветами столбцов"""
    client = docker.from_env()
    containers = get_dria_containers(client)
    
    if not containers:
        print("[INFO] Контейнеры с именем 'dria' не найдены.")
        return
    
    # Разбиваем контейнеры на три группы: 67, 67 и 66
    total_containers = len(containers)
    group_size = (total_containers + 2) // 3  # Округляем вверх: 200 / 3 = 66.67 → 67
    container_groups = [
        containers[0:group_size],              # dria1–dria67 (67 контейнеров)
        containers[group_size:2*group_size],   # dria68–dria134 (67 контейнеров)
        containers[2*group_size:]              # dria135–dria200 (66 контейнеров)
    ]
    
    # Создаем таблицы для каждой группы
    tables = [create_table_for_containers(group) for group in container_groups]
    
    # Получаем строковое представление каждой таблицы
    table_strings = [str(table).splitlines() for table in tables]
    
    # Определяем максимальную высоту таблицы
    max_height = max(len(table) for table in table_strings)
    
    # Выводим таблицы рядом с цветами
    for i in range(max_height):
        row_parts = []
        for table_lines in enumerate(table_strings):
            if i < len(table_lines[1]):
                # Раскрашиваем строку
                colored_row = colorize_row(table_lines[1][i], is_header=(i == 0))
                row_parts.append(colored_row)
            else:
                # Если таблица короче, добавляем пустую строку той же длины
                row_parts.append(" " * len(table_lines[1][0]))
        print("  ".join(row_parts))
    
    # Добавляем пустую строку в конце для читаемости
    print()

if __name__ == "__main__":
    monitor_dria_logs()