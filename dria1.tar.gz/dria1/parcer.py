import requests
import time
import pandas as pd

# Путь к файлу с адресами
input_file = "addr.txt"
excel_output = "results.xlsx"

# Указанный базовый URL API
url = "https://metrics.dria.co/api/v1/node_metrics"

# Функция для обработки одного адреса
def fetch_data_for_address(address):
    params = {
        "skip": 0,
        "limit": 20,
        "address": address.strip()
    }
    try:
        response = requests.get(url, params=params)
        response.raise_for_status()  # Вызывает исключение при ошибке HTTP
        data = response.json()
        results = []
        if "items" in data and isinstance(data["items"], list):
            for entry in data["items"]:
                completed_step = entry.get("completedStep")
                rank = entry.get("rank")
                results.append({
                    "completedStep": completed_step,
                    "rank": rank
                })
        if not results:
            results = [{"completedStep": 0, "rank": 0}]
        return results
    except requests.exceptions.RequestException:
        return [{"completedStep": 0, "rank": 0}]

# Основная логика
if __name__ == "__main__":
    try:
        # Чтение адресов из файла
        with open(input_file, "r") as file:
            addresses = file.readlines()

        # Загрузка предыдущих данных, если файл существует
        if pd.io.common.file_exists(excel_output):
            previous_data = pd.read_excel(excel_output)
        else:
            previous_data = pd.DataFrame(columns=["Address", "Completed Steps", "Rank"])

        excel_data = []

        print("Считываю данные...")
        start_time = time.time()

        # Обработка каждого адреса
        for address in addresses:
            address = address.strip()
            if not address:  # Пропустить пустые строки
                continue
            data = fetch_data_for_address(address)
            if data:
                excel_data.append({
                    "Address": address,
                    "Completed Steps": data[0]["completedStep"],
                    "Rank": data[0]["rank"]
                })

        # Преобразование в DataFrame
        new_data = pd.DataFrame(excel_data)
        new_data = new_data.sort_values(by="Completed Steps", ascending=False)

        # Объединение старых и новых данных
        combined_data = pd.merge(previous_data, new_data, on="Address", how="outer", suffixes=("_old", "_new"))
        combined_data["Step Growth"] = combined_data["Completed Steps_new"].fillna(0) - combined_data["Completed Steps_old"].fillna(0)
        combined_data["Rank Change"] = combined_data["Rank_old"].fillna(float('inf')) - combined_data["Rank_new"].fillna(float('inf'))

        # Сортировка по новым шагам
        combined_data = combined_data.sort_values(by="Completed Steps_new", ascending=False)

        # Сохранение в Excel
        combined_data.rename(columns={"Completed Steps_new": "Completed Steps", "Rank_new": "Rank"}, inplace=True)
        combined_data.drop(columns=["Completed Steps_old", "Rank_old"], inplace=True)
        combined_data.to_excel(excel_output, index=False)

        # Подсчёт адресов с приростом
        step_growth_count = combined_data[combined_data["Step Growth"] > 0].shape[0]
        rank_change_count = combined_data[combined_data["Rank Change"] != 0].shape[0]

        end_time = time.time()
        elapsed_time = end_time - start_time
        print(f"Данные успешно сохранены в {excel_output}")
        print(f"Проверка заняла {elapsed_time:.2f} секунд.")
        print(f"Количество кошельков с приростом Completed Steps: {step_growth_count}")
        print(f"Количество кошельков с изменением в рейтинге: {rank_change_count}")

    except FileNotFoundError:
        print(f"Файл {input_file} не найден. Проверьте путь и попробуйте снова.")
