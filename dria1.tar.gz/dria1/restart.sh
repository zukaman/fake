#!/bin/bash

# Путь к лог-файлу
LOG_FILE="/root/dria/restart_log.txt"

# Задержка между перезапусками контейнеров (в секундах)
DELAY_BETWEEN_CONTAINERS=10

# Задержка между циклами (24 часа = 86400 секунд)
DELAY_BETWEEN_CYCLES=86400

# Функция для логирования
log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" >> "$LOG_FILE"
}

# Бесконечный цикл
while true; do
    log "Starting container restart process..."

    # Получаем список контейнеров Dria
    CONTAINERS=$(docker ps -q --filter "name=dria")

    # Проверяем, есть ли контейнеры
    if [ -z "$CONTAINERS" ]; then
        log "No Dria containers found."
    else
        # Подсчитываем количество контейнеров
        NUM_CONTAINERS=$(echo "$CONTAINERS" | wc -l)
        log "Found $NUM_CONTAINERS Dria containers."

        # Перезапускаем каждый контейнер с паузой
        for CONTAINER in $CONTAINERS; do
            CONTAINER_NAME=$(docker inspect --format '{{.Name}}' "$CONTAINER" | sed 's/^\///')
            log "Restarting container: $CONTAINER_NAME"
            docker restart "$CONTAINER"
            if [ $? -eq 0 ]; then
                log "Successfully restarted container: $CONTAINER_NAME"
            else
                log "Failed to restart container: $CONTAINER_NAME"
            fi
            log "Waiting $DELAY_BETWEEN_CONTAINERS seconds before the next container..."
            sleep "$DELAY_BETWEEN_CONTAINERS"
        done
    fi

    log "Finished container restart process. Waiting 24 hours before the next cycle..."
    sleep "$DELAY_BETWEEN_CYCLES"
done
