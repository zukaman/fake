#!/bin/bash

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${YELLOW}Перезапуск контейнеров, которые не были обработаны ранее...${NC}"
echo ""

# Список контейнеров, которые не были обработаны (из вашего лога)
UNPROCESSED_CONTAINERS=(
    "dria17" "dria18" "dria19" "dria20" "dria21" "dria22" "dria23" "dria24" "dria25"
    "dria26" "dria27" "dria28" "dria29" "dria30" "dria31" "dria32" "dria33" "dria34"
    "dria51" "dria52" "dria53" "dria54" "dria55" "dria56" "dria57" "dria58" "dria59"
    "dria60" "dria61" "dria62" "dria63" "dria64" "dria65" "dria66" "dria83" "dria84"
    "dria85" "dria86" "dria87" "dria88" "dria89" "dria90" "dria91" "dria92" "dria93"
    "dria94" "dria95" "dria96" "dria97" "dria98"
)

# Счетчики
RESTARTED_COUNT=0
ALREADY_RUNNING_COUNT=0
NOT_FOUND_COUNT=0
ERROR_COUNT=0
TOTAL_COUNT=${#UNPROCESSED_CONTAINERS[@]}

echo -e "${BLUE}Найдено $TOTAL_COUNT контейнеров для проверки и перезапуска${NC}"
echo ""

# Функция для перезапуска контейнера
restart_container() {
    local container_name=$1
    
    # Проверяем существование контейнера
    if ! docker ps -a --format "{{.Names}}" | grep -q "^$container_name$"; then
        echo -e "${RED}❌ $container_name: контейнер не найден${NC}"
        return 3
    fi
    
    # Проверяем статус контейнера
    local container_status=$(docker ps -a --format "{{.Names}} {{.Status}}" | grep "^$container_name " | awk '{print $2}')
    
    if [[ $container_status == "Up" ]]; then
        echo -e "${YELLOW}🔄 $container_name: перезапускаем...${NC}"
        if docker restart "$container_name" > /dev/null 2>&1; then
            echo -e "${GREEN}✅ $container_name: успешно перезапущен${NC}"
            return 0
        else
            echo -e "${RED}❌ $container_name: ошибка при перезапуске${NC}"
            return 2
        fi
    else
        echo -e "${BLUE}ℹ️  $container_name: контейнер не запущен (статус: $container_status)${NC}"
        # Пытаемся запустить остановленный контейнер
        echo -e "${YELLOW}🚀 $container_name: пытаемся запустить...${NC}"
        if docker start "$container_name" > /dev/null 2>&1; then
            echo -e "${GREEN}✅ $container_name: успешно запущен${NC}"
            return 0
        else
            echo -e "${RED}❌ $container_name: ошибка при запуске${NC}"
            return 2
        fi
    fi
}

# Обрабатываем каждый контейнер
for container_name in "${UNPROCESSED_CONTAINERS[@]}"; do
    result=$(restart_container "$container_name")
    exit_code=$?
    
    case $exit_code in
        0)
            RESTARTED_COUNT=$((RESTARTED_COUNT + 1))
            ;;
        1)
            ALREADY_RUNNING_COUNT=$((ALREADY_RUNNING_COUNT + 1))
            ;;
        2)
            ERROR_COUNT=$((ERROR_COUNT + 1))
            ;;
        3)
            NOT_FOUND_COUNT=$((NOT_FOUND_COUNT + 1))
            ;;
    esac
    
    # Небольшая пауза между контейнерами
    sleep 0.5
done

echo ""
echo -e "${YELLOW}=== СТАТИСТИКА ПЕРЕЗАПУСКА ===${NC}"
echo -e "${GREEN}Успешно перезапущено/запущено: $RESTARTED_COUNT контейнеров${NC}"
echo -e "${BLUE}Контейнеров не найдено: $NOT_FOUND_COUNT${NC}"
echo -e "${RED}Ошибок при перезапуске: $ERROR_COUNT${NC}"
echo -e "${YELLOW}Всего обработано: $TOTAL_COUNT контейнеров${NC}"

if [ $ERROR_COUNT -eq 0 ] && [ $NOT_FOUND_COUNT -eq 0 ]; then
    echo -e "${GREEN}Все доступные контейнеры успешно перезапущены!${NC}"
elif [ $ERROR_COUNT -eq 0 ]; then
    echo -e "${YELLOW}Перезапуск завершен. Некоторые контейнеры не найдены (возможно, не созданы).${NC}"
else
    echo -e "${YELLOW}Перезапуск завершен с ошибками. Проверьте вывод выше.${NC}"
fi

echo ""
echo -e "${BLUE}Для проверки статуса всех контейнеров используйте:${NC}"
echo -e "${CYAN}docker ps | grep dria${NC}"
