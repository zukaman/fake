# -*- coding: utf-8 -*-
import docker
import os
import time
import sys
sys.stdout.reconfigure(encoding='utf-8')

# Путь к файлу с приватными ключами
WALLET_KEYS_FILE = "wallet.txt"

# Путь к файлу .env внутри контейнера
ENV_FILE_PATH = "/app/.env"

def read_keys(file_path):
    """Считывание ключей из файла, построчно"""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Файл {file_path} не найден")
    with open(file_path, "r") as f:
        return [line.strip() for line in f if line.strip()]

def start_container(client, container_base_name, image_name, index):
    """Запускает один контейнер с уникальным именем"""
    container_name = f"{container_base_name}{'' if index == 0 else index}"
    try:
        # Проверка, существует ли контейнер
        existing_container = client.containers.list(all=True, filters={"name": f"^{container_name}$"})
        if existing_container:
            print(f"[INFO] Контейнер {container_name} уже существует. Удаление...")
            existing_container[0].stop()
            existing_container[0].remove()
            print(f"[INFO] Контейнер {container_name} удален.")
        
        # Создание нового контейнера
        container = client.containers.run(
            image_name,
            name=container_name,
            detach=True,
            cap_add=["NET_ADMIN"]
        )
        print(f"[INFO] Контейнер {container_name} запущен.")
        return container
    except Exception as e:
        print(f"[ERROR] Не удалось запустить контейнер {container_name}: {e}")
        return None

def update_env_with_sed(container, wallet_key):
    """Обновление файла .env в контейнере с использованием sed"""
    try:
        sed_command = f"sed -i 's/^DKN_WALLET_SECRET_KEY=.*/DKN_WALLET_SECRET_KEY={wallet_key}/' {ENV_FILE_PATH}"
        container.exec_run(sed_command)
        print(f"[INFO] Контейнер {container.name}: файл .env обновлен.")
    except Exception as e:
        print(f"[ERROR] Не удалось обновить .env в контейнере {container.name}: {e}")

def restart_container(container):
    """Перезагрузка контейнера"""
    try:
        container.restart()
        print(f"[INFO] Контейнер {container.name} перезагружен.")
        time.sleep(2)
    except Exception as e:
        print(f"[ERROR] Не удалось перезагрузить контейнер {container.name}: {e}")

def main():
    client = docker.from_env()
    wallet_keys = read_keys(WALLET_KEYS_FILE)
    num_containers = len(wallet_keys)
    container_base_name = "dria"
    image_name = "dria"
    containers = []
    
    for i in range(num_containers):
        if i > 0:
            print(f"[INFO] Ожидаем 120 сек перед запуском следующего контейнера...")
            time.sleep(5)
        
        container = start_container(client, container_base_name, image_name, i)
        if container:
            containers.append(container)
            update_env_with_sed(container, wallet_keys[i])
            restart_container(container)

if __name__ == "__main__":
    main()
