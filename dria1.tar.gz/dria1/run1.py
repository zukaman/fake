# -*- coding: utf-8 -*-
import docker
import os
import time
import sys
sys.stdout.reconfigure(encoding='utf-8')

# Путь к файлу с приватными ключами
WALLET_KEYS_FILE = "wallet.txt"

# Путь к файлу .env внутри контейнера
ENV_FILE_PATH = "/app/.env"

MAX_RETRIES = 3


def read_keys(file_path):
    """Считывание ключей из файла, построчно"""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Файл {file_path} не найден")
    with open(file_path, "r") as f:
        return [line.strip() for line in f if line.strip()]

def start_container(client, container_base_name, image_name, index):
    """Запускает один контейнер с уникальным именем"""
    container_name = f"{container_base_name}{'' if index == 0 else index}"
    try:
        existing_container = client.containers.list(all=True, filters={"name": f"^{container_name}$"})
        if existing_container:
            print(f"[INFO] Контейнер {container_name} уже существует. Удаление...")
            existing_container[0].stop()
            existing_container[0].remove()
            print(f"[INFO] Контейнер {container_name} удален.")

        container = client.containers.run(
            image_name,
            name=container_name,
            detach=True,
            cap_add=["NET_ADMIN"],
            extra_hosts={"host.docker.internal": "172.17.0.1"}
        )
        print(f"[INFO] Контейнер {container_name} запущен.")
        return container
    except Exception as e:
        print(f"[ERROR] Не удалось запустить контейнер {container_name}: {e}")
        return None

def update_env_with_sed(container, wallet_key):
    """Обновление файла .env в контейнере с использованием sed"""
    try:
        sed_command = f"sed -i 's/^DKN_WALLET_SECRET_KEY=.*/DKN_WALLET_SECRET_KEY={wallet_key}/' {ENV_FILE_PATH}"
        container.exec_run(sed_command)
        print(f"[INFO] Контейнер {container.name}: файл .env обновлен.")
    except Exception as e:
        print(f"[ERROR] Не удалось обновить .env в контейнере {container.name}: {e}")

def restart_container(container):
    """Перезагрузка контейнера"""
    try:
        container.restart()
        print(f"[INFO] Контейнер {container.name} перезагружен.")
        time.sleep(2)
    except Exception as e:
        print(f"[ERROR] Не удалось перезагрузить контейнер {container.name}: {e}")

def wait_for_model_test(container, timeout=600):
    """Ожидает появления в логах строки о прохождении теста моделей"""
    print(f"[INFO] Ожидаем прохождение теста моделей в контейнере {container.name}...")
    start_time = time.time()
    while time.time() - start_time < timeout:
        logs = container.logs(tail=300).decode("utf-8")
        if "Ollama checks are finished" in logs:
            print(f"[OK] Контейнер {container.name}: тест моделей завершен.")
            return True
        time.sleep(5)
    print(f"[WARN] Контейнер {container.name}: тест моделей не завершился в течение {timeout} секунд.")
    return False

def deploy_with_retries(client, base_name, image_name, wallet_key, index):
    """Запускает контейнер и повторяет попытки при сбое теста моделей"""
    for attempt in range(1, MAX_RETRIES + 1):
        print(f"[INFO] Попытка {attempt} запуска контейнера {base_name}{'' if index == 0 else index}...")
        container = start_container(client, base_name, image_name, index)
        if container:
            update_env_with_sed(container, wallet_key)
            restart_container(container)
            if wait_for_model_test(container):
                print(f"[INFO] Контейнер {container.name} успешно прошёл тест моделей.")
                return True
            else:
                print(f"[RETRY] Тест не пройден. Удаляем и повторяем попытку...")
                container.stop()
                container.remove()
        time.sleep(5)
    print(f"[FAIL] Контейнер {base_name}{'' if index == 0 else index} не прошёл тест после {MAX_RETRIES} попыток.")
    return False

def main():
    client = docker.from_env()
    wallet_keys = read_keys(WALLET_KEYS_FILE)
    num_containers = len(wallet_keys)
    container_base_name = "dria"
    image_name = "dria"

    for i in range(num_containers):
        if not deploy_with_retries(client, container_base_name, image_name, wallet_keys[i], i):
            print(f"[ERROR] Остановка скрипта из-за неудачного запуска контейнера {i}.")
            break
        if i < num_containers - 1:
            print(f"[INFO] Подготовка к следующему контейнеру...")
            time.sleep(10)

if __name__ == "__main__":
    main()
