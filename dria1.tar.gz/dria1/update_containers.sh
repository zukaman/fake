#!/bin/bash

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Новые значения переменных
NEW_DKN_MODELS="gemma3:12b,gemma3:27b,gemma3:4b,llama3.1:8b-instruct-q4_K_M,llama3.2:1b-instruct-q4_K_M,llama3.3:70b-instruct-q4_K_M,mistral-nemo:12b,gemini-2.0-flash"
NEW_OLLAMA_HOST="http://135.181.56.99"
NEW_OLLAMA_PORT="11434"

# Путь к .env файлу внутри контейнера (измените если нужно)
ENV_FILE_PATH="/app/.env"

echo -e "${YELLOW}Начинаем обновление переменных окружения в контейнерах...${NC}"
echo -e "${YELLOW}Будут обработаны контейнеры: dria, dria2-dria100${NC}"
echo ""

# Счетчики для статистики
SUCCESS_COUNT=0
ERROR_COUNT=0
TOTAL_COUNT=0

# Функция для обновления переменных в контейнере
update_container_env() {
    local container_name=$1
    echo -e "${YELLOW}Обрабатываем контейнер: $container_name${NC}"
    
    # Проверяем существование контейнера
    if ! docker ps -a --format "{{.Names}}" | grep -q "^$container_name$"; then
        echo -e "${RED}  Контейнер $container_name не найден${NC}"
        return 1
    fi
    
    # Проверяем запущен ли контейнер
    if ! docker ps --format "{{.Names}}" | grep -q "^$container_name$"; then
        echo -e "${RED}  Контейнер $container_name не запущен${NC}"
        return 1
    fi
    
    # Создаем backup оригинального .env файла
    echo "  Создаем backup оригинального .env..."
    docker exec $container_name cp $ENV_FILE_PATH ${ENV_FILE_PATH}.backup 2>/dev/null
    
    # Обновляем переменные
    echo "  Обновляем переменные окружения..."
    
    # Обновляем DKN_MODELS
    docker exec $container_name sed -i "s|^DKN_MODELS=.*|DKN_MODELS=$NEW_DKN_MODELS|g" $ENV_FILE_PATH
    if [ $? -ne 0 ]; then
        echo -e "${RED}  Ошибка при обновлении DKN_MODELS${NC}"
        return 1
    fi
    
    # Обновляем OLLAMA_HOST
    docker exec $container_name sed -i "s|^OLLAMA_HOST=.*|OLLAMA_HOST=$NEW_OLLAMA_HOST|g" $ENV_FILE_PATH
    if [ $? -ne 0 ]; then
        echo -e "${RED}  Ошибка при обновлении OLLAMA_HOST${NC}"
        return 1
    fi
    
    # Обновляем OLLAMA_PORT
    docker exec $container_name sed -i "s|^OLLAMA_PORT=.*|OLLAMA_PORT=$NEW_OLLAMA_PORT|g" $ENV_FILE_PATH
    if [ $? -ne 0 ]; then
        echo -e "${RED}  Ошибка при обновлении OLLAMA_PORT${NC}"
        return 1
    fi
    
    echo "  Перезапускаем контейнер..."
    docker restart $container_name > /dev/null 2>&1
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}  ✓ Контейнер $container_name успешно обновлен и перезапущен${NC}"
        return 0
    else
        echo -e "${RED}  ✗ Ошибка при перезапуске контейнера $container_name${NC}"
        return 1
    fi
}

# Обрабатываем контейнер dria (первый)
TOTAL_COUNT=$((TOTAL_COUNT + 1))
if update_container_env "dria"; then
    SUCCESS_COUNT=$((SUCCESS_COUNT + 1))
else
    ERROR_COUNT=$((ERROR_COUNT + 1))
fi
echo ""

# Обрабатываем контейнеры dria2-dria100 (пропускаем dria1)
for i in {2..100}; do
    container_name="dria$i"
    TOTAL_COUNT=$((TOTAL_COUNT + 1))
    
    if update_container_env "$container_name"; then
        SUCCESS_COUNT=$((SUCCESS_COUNT + 1))
    else
        ERROR_COUNT=$((ERROR_COUNT + 1))
    fi
    echo ""
    
    # Небольшая пауза между контейнерами чтобы не перегружать систему
    sleep 1
done

# Выводим статистику
echo -e "${YELLOW}=== СТАТИСТИКА ВЫПОЛНЕНИЯ ===${NC}"
echo -e "${GREEN}Успешно обработано: $SUCCESS_COUNT контейнеров${NC}"
echo -e "${RED}Ошибок: $ERROR_COUNT контейнеров${NC}"
echo -e "${YELLOW}Всего обработано: $TOTAL_COUNT контейнеров${NC}"

if [ $ERROR_COUNT -eq 0 ]; then
    echo -e "${GREEN}Все контейнеры успешно обновлены!${NC}"
else
    echo -e "${YELLOW}Обновление завершено с ошибками. Проверьте вывод выше.${NC}"
fi
